import UIKit

var str = "Heljo, playground"
print(str)

struct Book {
    var num : Int
    var name : String
    var author : String
}

func testMethod(_ count : Int) -> [Book] {
    
    return (0..<count).map{ index in
        Book(num : index, name : "Pruthvi", author : "Henly")
    }
}

struct Identifier : Hashable{
    let string : String
}

struct User {
    let id : Identifier
    let name : String
}

print(testMethod(6).first?.num ?? "Hello")

let index = str.index(str.startIndex, offsetBy: 3)
print(str[index...])

struct LongestPalinString {
    
    var palinString : String
    
    init(str : String) {
        self.palinString = str
        printLongestPalinString()
    }
    
    private func printLongestPalinString() {
        
        var maxLength = 0
        var start = 0
        
        for (index, _) in palinString.enumerated() {
            
             // Even palin
            var high = index
            var low = index - 1
            
            while (low >= 0 && high < palinString.count && palinString[palinString.index(palinString.startIndex, offsetBy: high)] == palinString[palinString.index(palinString.startIndex, offsetBy: low)]) {
                if high - low + 1 > maxLength {
                    start = low
                    maxLength = high - low + 1
                }
                low -= 1
                high += 1
            }
            
            //Odd Palin
            high = index + 1
            low = index - 1
            
            while (low >= 0 && high < palinString.count && palinString[palinString.index(palinString.startIndex, offsetBy: high)] == palinString[palinString.index(palinString.startIndex, offsetBy: low)]) {
                if high - low + 1 > maxLength {
                    start = low
                    maxLength = high - low + 1
                }
                low -= 1
                high += 1
            }
            
        }
        
        print("\(start) and \(maxLength)")
        
        let palinStartIndex = palinString.index(palinString.startIndex, offsetBy: start)
        let palinEndIndex = palinString.index(palinStartIndex, offsetBy: maxLength)
        let range = palinStartIndex..<palinEndIndex
        print(palinString[range])
    }
    
}

var palinSStruct = LongestPalinString.init(str: "malayalam")

struct ZigZagStruct {
    var row : Int
    var character : Character
}

struct ZigZagSample {

    let zigZagStr = "PAYPALISRISING"
    var rowCount : Int
  
    
    init(rowCount : Int) {
        self.rowCount = rowCount
        getZigZagStr()
    }
    
    private func getZigZagStr() {
        var row = 0
        var down = true
        var zigZagArray = [ZigZagStruct]()
        
        for (_, ch) in zigZagStr.enumerated() {
            
            let str = ZigZagStruct.init(row: row, character: ch)
            zigZagArray.append(str)
            
            if row == rowCount - 1 {
                down = false
            } else if row == 0 {
                down = true
            }
            
            if down {
                row += 1
            } else {
                row -= 1
            }
        }
        
        var zigZagStrDisplay = ""
        
        let indexes = (0..<self.rowCount).map{ index in
            
            return zigZagArray.filter{$0.row == index}
            }.flatMap { return $0 }
        
        for z in indexes {
            zigZagStrDisplay += "\(z.character)"
        }
        
        print(zigZagStrDisplay)
    }
}

let zigZag = ZigZagSample(rowCount: 6)

struct StringToInt {
    
    var stringToConvert : String
    
    init(stringToConvert : String) {
        self.stringToConvert = stringToConvert
        convertStringToInteger()
    }
    
    private func convertStringToInteger() {
        
        removeWhiteSpacesForString()
    }
    
    private func removeWhiteSpacesForString() {
     
        let nowhiteSpaceString = stringToConvert.components(separatedBy: .whitespacesAndNewlines).joined(separator: "")
        
        var negativeSign = ""
        
        let firstChar = nowhiteSpaceString[nowhiteSpaceString.index(nowhiteSpaceString.startIndex, offsetBy: 0)]
        
        if "-" == String(firstChar) {
            negativeSign = String(firstChar)
        }
        
        let nolettersString = nowhiteSpaceString.components(separatedBy: .letters).joined(separator: "")
        var replaceOtherString = nolettersString.components(separatedBy: .punctuationCharacters).joined(separator: "")
        replaceOtherString = negativeSign + replaceOtherString
        
        
        if let number = Int(replaceOtherString) {
            print(number)
        }
       
        
    }
}

StringToInt.init(stringToConvert: " -64   &-sgfd895439")

struct RomanNumeral {
    
    enum Symbols : Int {
        case I = 1
        case II = 2
        case III = 3
        case IV = 4
        case V = 5
        case VI = 6
        case VII = 7
        case VIII = 8
        case IX = 9
        case X = 10
        case L = 50
        case C = 100
        case D = 500
        case M = 1000
        
    }
    
    private var numInt : Int
    
    init(num : Int) {
        numInt = num
        printRomanNumeral()
    }
    
    private mutating func printRomanNumeral() {
        
        var symbolToPrint = ""
        print("Hello")
        repeat {
            let symbol = getSymbolForNum(numInt)
            symbolToPrint = symbol + symbolToPrint
            numInt = numInt / 10
        } while (numInt / 10 != 0)
        
        print(symbolToPrint)
    }
    
    private func getSymbolForNum(_ num : Int) -> String {
        var symbol = ""
        
        var strippedNum = num
        var placeIndex = 0
        var remainder = strippedNum
        
        print("--\(remainder)")
        
        while strippedNum != 0 {
            remainder = strippedNum % 10
            strippedNum = strippedNum / 10
            placeIndex += 1
        }
        
        print("--\(remainder)")
        print("** \(placeIndex)")
        
       symbol = String(reflecting: Symbols.init(rawValue: strippedNum))
        
        return symbol
    }
}

let romanNumeral = RomanNumeral.init(num: 42)


struct SubFilesMerge {
    
    private var subFiles : [Int]
    
    init(subFiles : [Int]) {
        self.subFiles = subFiles
        mergeSubFiles()
    }
    
    private func mergeSubFiles() {
        var orderedSubFiles = subFiles
        
        var totalSum = 0
        
        while orderedSubFiles.count >= 2 {
            
            orderedSubFiles = orderedSubFiles.sorted()
            
            let sum = orderedSubFiles.first! + orderedSubFiles[1]
            totalSum += sum
            orderedSubFiles.remove(at: 0)
            orderedSubFiles.remove(at: 0)
            orderedSubFiles.append(sum)

            
        }
        
        print(totalSum)
        
    }
}

SubFilesMerge(subFiles: [2, 2, 3, 3])

class Solution {
    let phoneDict: [Int : String] = [
        2 : "abc",
        3 : "def",
        4 : "ghi",
        5 : "jkl",
        6 : "mno",
        7 : "pqrs",
        8 : "tuv",
        9 : "wxyz"
    ]
    func letterCombinations(_ digits: String) -> [String] {
        var combinations = [String]()
        for digit in Array(digits) {
            guard let number = Int(String(digit)),
                let letters = phoneDict[number] else {
                    continue
            }
            var newCombinations = [String]()
            print("**\(digit)")
            for letter in Array(letters) {
                if combinations.count == 0 {
                    newCombinations.append(String(letter))
                } else {
                    newCombinations += combinations.map({$0 + String(letter)})
                }
            }
            combinations = newCombinations
            print("--\(combinations)")

        }
        return combinations
    }
}

let solution = Solution()
print(solution.letterCombinations("237"))



 // Definition for singly-linked list.
 public class ListNode {
    
    public var val: Int
    public var next: ListNode?
    public init(_ val: Int) {
         self.val = val
        self.next = nil
      }
 }

class SolutionList {
    func removeNthFromEnd(_ head: ListNode?, _ n: Int) -> ListNode? {
        
        var nFromEnd = head
        
        var currentNode = head
        
        var count = 0
        
        while currentNode?.next != nil {
            
            currentNode = currentNode?.next
            count += 1
        }
        
        var j = 0
        
        currentNode = head
        
        while currentNode != nil {
            
            if (count - n) == j {
                currentNode?.next = currentNode?.next?.next
                
            } else {
                currentNode = currentNode?.next
            }
            
            j += 1
            
        }
        
        
        return nFromEnd
        
    }
}


struct Stars {
    
    private let count : Int
    
    init(count : Int) {
        self.count = count
        drawStars()
    }
    
    private func drawStars() {
        
        var counter = count
        
        while counter > 0 {
            
            var starParam = ""
            (0..<counter).map{ _ in starParam += "*" }
          
            print(starParam)
           
            counter -= 1
            
        }
        
    }
    
}

Stars(count: 5)

struct TwoSumClosest {
    
    private let target : Int
    private let firstArray : [Int]
    private let secondArray : [Int]
    
    init(_ arr1 : [Int], _ arr2 : [Int], _ target : Int) {
        firstArray = arr1
        secondArray = arr2
        self.target = target
        findClosestToTarget()
    }
    
    private func findClosestToTarget() {
        
        var closestMatch = [Int]()
        
        var closestToTarget = abs(self.target - (firstArray.first! + secondArray.first!))
        
        for ele in firstArray {
            
            for secondEle in secondArray {
                
                let targ = secondEle + ele
                let targDiff = abs(self.target - targ)
                
                if targDiff <= closestToTarget {
                    
                    print(closestToTarget)
                    closestToTarget = targDiff
                    closestMatch.removeAll()
                    closestMatch.append(ele)
                    closestMatch.append(secondEle)
                }
            
            }
        }
        
        
        print(closestMatch)
        
    }
    
}

let arr1 = [3, 7, 9]
let arr2 = [9, 19, 24]
let target = 30

TwoSumClosest(arr1, arr2, target)


struct SingleElementFinder {
    
    private let array : [Int]
    
    init(firstArray : [Int]) {
        array = firstArray
        findOrphanElement()
    }
    
    private func findOrphanElement() {
        
        var prevElement = 0
        var orphanElement : Int?
        
        for (i, ele) in array.enumerated() {
            
            if i % 2 == 0 {
                
                if i == (array.count - 1) {
                    orphanElement = ele
                    break
                }
                
                prevElement = ele
            } else {
                
                if prevElement == ele {
                    continue
                } else {
                    
                    var nextElement : Int?
                    
                    if (i + 1) < array.count {
                        nextElement = array[i + 1]
                    }
                    
                    if let next = nextElement, next == ele {
                        
                        orphanElement = prevElement
                    } else {
                        orphanElement = ele
                    }
                    
                    
                    break
                }
            }
        }
        
        if let orphan = orphanElement {
            print(orphan)
        }
        
    }
}

let array = [1,1,2]
SingleElementFinder(firstArray: array)



class RecSolution {
    
    func combinationSum(_ candidates: [Int], _ target: Int) -> [[Int]] {
        var result = [[Int]]()
        var candidate = [Int]()
        
        backtracking(&result, &candidate, candidates.sorted(), target, 0)
        
        return result
    }
    
    private func backtracking(_ result: inout [[Int]], _ candidate: inout [Int], _ inputs: [Int], _ remain: Int, _ start: Int) {
        if remain < 0 {
            return
        } else if remain == 0 {
            result.append(candidate)
        } else {
            for i in start..<inputs.count {
                
                candidate.append(inputs[i])
                backtracking(&result, &candidate, inputs, remain - inputs[i], i)
                candidate.removeLast()
            }
        }
    }
}

var targetComb = [2,3, 6, 7]
let targ = 7

RecSolution().combinationSum(targetComb, targ)


for index in 1..<9 {
    print("My index is \(index)")
}

print(7/3 * 3)










